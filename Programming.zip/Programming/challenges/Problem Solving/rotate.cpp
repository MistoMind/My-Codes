#include <bits/stdc++.h>
using namespace std;

struct Layer{
	int x1, x2, y1, y2;
};

void matrixRotation(vector<vector<int>> matrix, int r) {
	int m = matrix.size();
	int n = matrix[0].size();
	struct Layer lay;
	lay.x1 = 0;
	lay.x2 = m;
	lay.y1 = 0;
	lay.y2 = n;

	for(int rotation=1;rotation<=r;rotation++){

	}
}

int main(){
	fstream fin("rotate_input.txt");

	int r, m, n, num;
	vector<vector<int>> matrix;
	fin >> m >> n >> r;

	for(int i=0;i<m;i++){
		vector<int> temp;
		for(int j=0;j<n;j++){
			fin >> num;
			temp.push_back(num);
		}
		matrix.push_back(temp);
	}

	matrixRotation(matrix, r);

	fin.close();
}