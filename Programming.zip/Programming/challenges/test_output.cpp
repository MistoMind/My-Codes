#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main(){
	ifstream fin1("my_output.txt");
	ifstream fin2("expected_output.txt");
	string my, expected;
	int line_no=0;

	if(!fin1 || !fin2){
		cout << "Error: cant't open the file" << endl;
	}

	while(fin1 || fin2){
		fin1 >> my;
		fin2 >> expected;

		cout << "Checking: " << endl;
		cout << "My = " << my << endl;
		cout << "Expected = " << expected << endl;
		cout << "Line number = " << line_no << endl;

		if(my!=expected){
			cout << "\t\t\t\t\tDon't match" << endl;
			cout << "My = " << my << endl;
			cout << "Expected = " << expected << endl;
			cout << "Line number = " << line_no << endl;
			break;
		}
		line_no++;
	}

	fin1.close();
	fin2.close();
}