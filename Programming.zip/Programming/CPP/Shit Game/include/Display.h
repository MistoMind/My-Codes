#ifndef DISPLAY_H
#define DISPLAY_H

#include <iostream>
#include "Map.h"
using namespace std;

class Display{
    public:
        Display();
        void controls();
};

#endif